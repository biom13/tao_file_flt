# Day_len_GitHub.ps1
# Day code len https://github.com/biom13/tao_file_flt va bat GitHub Pages, khong can thao tac tren web.
# Chay: nhap dup Day_len_GitHub.bat  (hoac: powershell -ExecutionPolicy Bypass -File .\Day_len_GitHub.ps1)

$Owner    = 'biom13'
$Repo     = 'tao_file_flt'
$Branch   = 'main'
$RepoUrl  = "https://github.com/$Owner/$Repo.git"
$PagesUrl = "https://$Owner.github.io/$Repo/"

$ErrorActionPreference = 'Continue'
Set-Location -LiteralPath $PSScriptRoot

function Step([string]$Message) {
    Write-Host ''
    Write-Host "== $Message" -ForegroundColor Cyan
}

# Chay lenh ngoai (git, gh); neu loi thi dung va bao ra
function Run([string]$Exe, [string[]]$Params) {
    & $Exe @Params
    if ($LASTEXITCODE -ne 0) {
        throw "Lenh that bai: $Exe $($Params -join ' ') (ma loi $LASTEXITCODE)"
    }
}

function Has([string]$Name) {
    return [bool](Get-Command $Name -ErrorAction SilentlyContinue)
}

function Refresh-Path {
    $machine = [Environment]::GetEnvironmentVariable('Path', 'Machine')
    $user    = [Environment]::GetEnvironmentVariable('Path', 'User')
    $env:Path = "$machine;$user"
}

try {
    Write-Host '============================================================'
    Write-Host "  DAY CODE LEN GITHUB: $Owner/$Repo"
    Write-Host '============================================================'

    # ---------- 1. Kiem tra git va GitHub CLI ----------
    Step '1. Kiem tra git va GitHub CLI (gh)'
    if (-not (Has 'git')) {
        Write-Host 'Chua co git, dang cai bang winget...'
        & winget install --id Git.Git -e --source winget --accept-package-agreements --accept-source-agreements
        Refresh-Path
    }
    if (-not (Has 'gh')) {
        Write-Host 'Chua co GitHub CLI, dang cai bang winget...'
        & winget install --id GitHub.cli -e --source winget --accept-package-agreements --accept-source-agreements
        Refresh-Path
    }
    if (-not (Has 'git')) { throw 'Van chua thay git. Hay dong cua so nay, mo lai va chay lai script.' }
    if (-not (Has 'gh'))  { throw 'Van chua thay gh. Hay dong cua so nay, mo lai va chay lai script.' }
    Write-Host (& git --version)
    Write-Host (& gh --version | Select-Object -First 1)

    # ---------- 2. Dang nhap GitHub (chi can lam 1 lan) ----------
    Step '2. Dang nhap GitHub'
    & gh auth status *> $null
    if ($LASTEXITCODE -ne 0) {
        Write-Host 'Chua dang nhap. Lam theo huong dan hien ra (dang nhap 1 lan bang trinh duyet).'
        Run 'gh' @('auth', 'login', '--hostname', 'github.com', '--git-protocol', 'https', '--web')
    } else {
        Write-Host 'Da dang nhap GitHub.'
    }
    Run 'gh' @('auth', 'setup-git')

    # ---------- 3. Kiem tra repo ----------
    Step "3. Kiem tra repo $Owner/$Repo"
    $visibility = (& gh repo view "$Owner/$Repo" --json visibility --jq '.visibility')
    if ($LASTEXITCODE -ne 0) {
        throw "Khong truy cap duoc repo $Owner/$Repo. Kiem tra ten repo va tai khoan dang nhap co quyen ghi."
    }
    Write-Host "Che do repo: $visibility"
    if ($visibility -eq 'PRIVATE') {
        Write-Host 'GitHub Pages mien phi chi chay voi repo PUBLIC.' -ForegroundColor Yellow
        $ans = Read-Host 'Chuyen repo sang public? Code add-in se hien cong khai, khong co du lieu Excel (Y/N)'
        if ($ans -match '^[Yy]') {
            Run 'gh' @('repo', 'edit', "$Owner/$Repo", '--visibility', 'public', '--accept-visibility-change-consequences')
        } else {
            throw 'Giu repo private nen khong bat duoc GitHub Pages mien phi. Dung lai.'
        }
    }

    # ---------- 4. Khoi tao git local va commit ----------
    Step '4. Khoi tao git va commit'
    if (-not (Test-Path -LiteralPath '.git')) {
        Run 'git' @('init')
    }
    Run 'git' @('symbolic-ref', 'HEAD', "refs/heads/$Branch")

    $gitName  = (& git config user.name)
    $gitEmail = (& git config user.email)
    if (-not $gitName) {
        Run 'git' @('config', 'user.name', $Owner)
    }
    if (-not $gitEmail) {
        $userId = (& gh api user --jq '.id')
        Run 'git' @('config', 'user.email', "$userId+$Owner@users.noreply.github.com")
    }

    Run 'git' @('add', '-A')
    $pending = (& git status --porcelain)
    if ($pending) {
        Run 'git' @('commit', '-m', 'Add Excel add-in tao file FLT')
    } else {
        Write-Host 'Khong co thay doi moi de commit.'
    }

    # ---------- 5. Gan remote va push ----------
    Step '5. Day code len GitHub'
    $remotes = @(& git remote)
    if ($remotes -contains 'origin') {
        Run 'git' @('remote', 'set-url', 'origin', $RepoUrl)
    } else {
        Run 'git' @('remote', 'add', 'origin', $RepoUrl)
    }

    & git push -u origin $Branch
    if ($LASTEXITCODE -ne 0) {
        Write-Host 'Repo tren GitHub da co noi dung san, dang gop lai roi push...' -ForegroundColor Yellow
        Run 'git' @('pull', 'origin', $Branch, '--allow-unrelated-histories', '--no-edit', '-X', 'ours')
        Run 'git' @('push', '-u', 'origin', $Branch)
    }

    # ---------- 6. Bat GitHub Pages ----------
    Step '6. Bat GitHub Pages'
    $pagesApi = "repos/$Owner/$Repo/pages"
    & gh api -X POST $pagesApi -f "source[branch]=$Branch" -f "source[path]=/" *> $null
    if ($LASTEXITCODE -ne 0) {
        # Co the Pages da duoc bat truoc do -> cap nhat nguon
        & gh api -X PUT $pagesApi -f "source[branch]=$Branch" -f "source[path]=/" *> $null
        if ($LASTEXITCODE -ne 0) {
            & gh api $pagesApi *> $null
            if ($LASTEXITCODE -ne 0) {
                throw 'Khong bat duoc GitHub Pages bang API. Kiem tra repo la public va tai khoan co quyen admin.'
            }
        }
    }
    Write-Host 'Da bat GitHub Pages (nhanh main, thu muc goc).'

    # ---------- 7. Cho GitHub Pages build xong ----------
    Step '7. Cho GitHub Pages xuat ban (toi da khoang 5 phut)'
    $state = ''
    for ($i = 1; $i -le 30; $i++) {
        $state = (& gh api "$pagesApi/builds/latest" --jq '.status' 2>$null)
        Write-Host "  [$i/30] trang thai: $state"
        if ($state -eq 'built' -or $state -eq 'errored') { break }
        Start-Sleep -Seconds 10
    }

    $httpCode = 0
    try {
        $resp = Invoke-WebRequest -Uri ($PagesUrl + 'taskpane.html') -UseBasicParsing -TimeoutSec 20
        $httpCode = [int]$resp.StatusCode
    } catch {
        $httpCode = 0
    }

    Write-Host ''
    Write-Host '============================================================'
    if ($httpCode -eq 200) {
        Write-Host '  HOAN TAT! Add-in da online:' -ForegroundColor Green
    } else {
        Write-Host '  Code da len GitHub nhung trang chua mo duoc (co the can them 1-2 phut).' -ForegroundColor Yellow
        Write-Host '  Thu mo link ben duoi bang trinh duyet sau it phut.'
    }
    Write-Host "  Trang add-in : $($PagesUrl)taskpane.html"
    Write-Host "  Repo         : https://github.com/$Owner/$Repo"
    Write-Host "  File manifest: $(Join-Path $PSScriptRoot 'manifest.xml')"
    Write-Host '  Buoc tiep    : cai manifest.xml vao Excel 2021 (xem README.md, Buoc 3).'
    Write-Host '============================================================'
}
catch {
    Write-Host ''
    Write-Host "LOI: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ''
Read-Host 'Nhan Enter de dong'
