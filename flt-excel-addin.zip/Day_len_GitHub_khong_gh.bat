@echo off
title Day code len GitHub (khong can gh)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Day_len_GitHub_khong_gh.ps1"
