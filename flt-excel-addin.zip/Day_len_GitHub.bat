@echo off
title Day code len GitHub
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Day_len_GitHub.ps1"
